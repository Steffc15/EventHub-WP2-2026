// Tiny optional backend example using Node + Express.
// Run:
//   npm install express cors
//   node server.js

const express = require('express');
const cors = require('cors');
const fs = require('fs');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3000;
const eventsPath = path.join(__dirname, 'events.json');

app.use(cors());
app.use(express.json());
app.use(express.static(__dirname));

let reservations = [
  {
    id: 101,
    eventId: 1,
    fullName: 'Jane Doe',
    email: 'jane@example.com',
    seats: 2,
    status: 'confirmed'
  },
  {
    id: 102,
    eventId: 2,
    fullName: 'Jane Doe',
    email: 'jane@example.com',
    seats: 1,
    status: 'confirmed'
  },
  {
    id: 103,
    eventId: 3,
    fullName: 'Jane Doe',
    email: 'jane@example.com',
    seats: 1,
    status: 'confirmed'
  }
];

function readEvents() {
  const raw = fs.readFileSync(eventsPath, 'utf8');
  return JSON.parse(raw);
}

app.get('/api/events', (req, res) => {
  const { search = '', category = '', location = '', date = '' } = req.query;
  const events = readEvents();

  const filtered = events.filter((event) => {
    const matchesSearch = !search || event.title.toLowerCase().includes(search.toLowerCase());
    const matchesCategory = !category || event.category.toLowerCase() === category.toLowerCase();
    const matchesLocation = !location || event.location.toLowerCase().includes(location.toLowerCase());
    const matchesDate = !date || event.date === date;

    return matchesSearch && matchesCategory && matchesLocation && matchesDate;
  });

  res.json(filtered);
});

app.get('/api/reservations', (req, res) => {
  const events = readEvents();

  const reservationDetails = reservations.map((reservation) => {
    const event = events.find((item) => item.id === reservation.eventId);

    return {
      ...reservation,
      event
    };
  });

  res.json(reservationDetails);
});

app.post('/api/reservations', (req, res) => {
  const { eventId, fullName, email, seats = 1 } = req.body;

  if (!eventId || !fullName || !email) {
    return res.status(400).json({ message: 'eventId, fullName, and email are required.' });
  }

  const reservation = {
    id: Date.now(),
    eventId: Number(eventId),
    fullName,
    email,
    seats: Number(seats),
    status: 'confirmed'
  };

  reservations.push(reservation);

  res.status(201).json({
    message: 'Reservation received.',
    reservation
  });
});

app.delete('/api/reservations/:id', (req, res) => {
  const reservationId = Number(req.params.id);
  const existing = reservations.find((reservation) => reservation.id === reservationId);

  if (!existing) {
    return res.status(404).json({ message: 'Reservation not found.' });
  }

  reservations = reservations.filter((reservation) => reservation.id !== reservationId);

  res.json({ message: 'Reservation canceled successfully.' });
});

app.listen(PORT, () => {
  console.log(`EventHub server running on http://localhost:${PORT}`);
});