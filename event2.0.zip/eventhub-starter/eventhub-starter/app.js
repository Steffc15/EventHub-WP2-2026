const events = [
  { id: 1, title: 'City Charity Marathon', category: 'Charity', location: 'Miami, FL', date: '2026-06-20', image: 'https://images.unsplash.com/photo-1452626038306-9aae5e071dd3?q=80&w=1000&auto=format&fit=crop', description: 'Run for a cause through the heart of Miami.', seatsAvailable: 100 },
  { id: 2, title: 'Echoes of Summer', category: 'Music', location: 'Austin, TX', date: '2026-07-12', image: 'https://images.unsplash.com/photo-1501281668745-f7f57925c3b4?q=80&w=1000&auto=format&fit=crop', description: 'A music festival featuring top indie artists.', seatsAvailable: 75 },
  { id: 3, title: 'Retro Gaming Expo', category: 'Gaming', location: 'Tokyo, Japan', date: '2026-08-30', image: 'https://images.unsplash.com/photo-1511512578047-dfb367046420?q=80&w=1000&auto=format&fit=crop', description: 'Explore the golden era of video games.', seatsAvailable: 10 },
  { id: 4, title: 'Winter Wonderland Ball', category: 'Gala', location: 'Zurich, Switzerland', date: '2026-12-15', image: 'https://images.pexels.com/photos/2306281/pexels-photo-2306281.jpeg?auto=compress&cs=tinysrgb&w=800', description: 'An elegant evening in a snowy paradise.', seatsAvailable: 50 }
];

let reservations = [];

function showPage(pageId) {
  document.querySelectorAll('.page-section').forEach(s => s.style.display = 'none');
  const active = document.getElementById(pageId);
  if (active) active.style.display = 'block';
  if (pageId === 'events') renderCards(events);
  if (pageId === 'reservations') renderReservations();
  window.scrollTo(0, 0);
}

function formatDate(val) {
  return new Date(val + 'T00:00:00').toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' });
}

function renderCards(list) {
  const grid = document.getElementById('eventsGrid');
  if (!grid) return;
  grid.innerHTML = list.map(event => `
    <article class="event-row-item">
      <div class="event-row">
        <img class="event-row-image" src="${event.image}" alt="${event.title}" onerror="this.src='https://placehold.co/600x400?text=Event+Image'">
        <div class="event-row-info">
          <h3>${event.title}</h3>
          <p><strong>${event.location}</strong> • ${formatDate(event.date)}</p>
          <div class="event-divider"></div>
          <p>Available Seats: <strong>${event.seatsAvailable}</strong></p>
        </div>
        <div class="event-row-action">
          <button class="action-btn btn-outline" onclick="alert('${event.description}')">Details</button>
          <button class="action-btn btn-rose" onclick="reserveEvent(${event.id})" ${event.seatsAvailable <= 0 ? 'disabled' : ''}>
            ${event.seatsAvailable <= 0 ? 'Sold Out' : 'Book Now'}
          </button>
        </div>
      </div>
    </article>
  `).join('');
}

function renderReservations() {
  const list = document.getElementById('reservationsList');
  if (!list) return;
  if (!reservations.length) {
    list.innerHTML = '<div style="text-align:center; padding: 50px;"><h3>No bookings found.</h3></div>';
    return;
  }
  list.innerHTML = reservations.map(res => {
    const event = events.find(e => e.id === res.eventId);
    return `
      <div class="event-row-item">
        <div class="event-row">
            <img class="event-row-image" src="${event.image}">
            <div class="event-row-info">
                <h3>${event.title}</h3>
                <p>${formatDate(event.date)}</p>
                <p>Status: <span style="color:green; font-weight:bold;">Confirmed</span></p>
            </div>
            <div class="event-row-action">
                <button class="action-btn btn-dark" onclick="cancelReservation(${res.id})">Cancel</button>
            </div>
        </div>
      </div>
    `;
  }).join('');
}

function reserveEvent(id) {
  const event = events.find(e => e.id === id);
  if (event.seatsAvailable > 0) {
    event.seatsAvailable--;
    reservations.push({ id: Date.now(), eventId: id });
    alert(`Success! Ticket reserved for ${event.title}`);
    renderCards(events);
  }
}

function cancelReservation(id) {
  const res = reservations.find(r => r.id === id);
  const event = events.find(e => e.id === res.eventId);
  event.seatsAvailable++;
  reservations = reservations.filter(r => r.id !== id);
  renderReservations();
}

document.getElementById('searchInput')?.addEventListener('input', (e) => {
  const val = e.target.value.toLowerCase();
  renderCards(events.filter(ev => ev.title.toLowerCase().includes(val)));
});

window.onload = () => showPage('home');